var rect= require('./rectangle');
function solveRect(l,b){
    console.log("solving");
    
    rect(l,b,(err,rectangle)=>{
        if(err){
            console.log("Errror: "+err.message);
        }
        else{
            console.log("Are is "+ rectangle.area());
        }
    })
    console.log("Done");
}

solveRect(2,4);
